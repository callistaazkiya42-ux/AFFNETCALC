# AFFNETCALC — Build APK via GitHub Actions

Project Android AFFNETCALC 9 ODP cascaded.

## Cara build
1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini ke root repository, termasuk folder `.github`.
3. Commit ke branch `main`.
4. Buka tab **Actions** > **Build AFFNETCALC APK**.
5. Tekan **Run workflow** jika build belum berjalan otomatis.
6. Setelah status hijau, buka hasil run lalu download artifact **AFFNETCALC-APK**.
7. Ekstrak artifact ZIP. Di dalamnya ada **AFFNETCALC.apk**.

APK debug ditandatangani otomatis oleh Android Gradle Plugin dan dapat dipasang untuk pengujian di Android.
