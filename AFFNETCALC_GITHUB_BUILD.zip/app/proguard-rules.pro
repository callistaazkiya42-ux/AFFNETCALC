# No custom ProGuard rules required for this lightweight WebView app.
